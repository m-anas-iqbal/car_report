<?php
Route::get('/car-diagnostics', [\App\Http\Controllers\PagesController::class, 'cardiagnostics'])->name('car-diagnostics');
Route::get('/mot-services', [\App\Http\Controllers\PagesController::class, 'motservices'])->name('mot-services');
Route::get('/general-car-repairs', [\App\Http\Controllers\PagesController::class, 'generalcarrepairs'])->name('general-car-repairs');
Route::get('/air-conditioning', [\App\Http\Controllers\PagesController::class, 'airconditioning'])->name('air-conditioning');
Route::get('/contact-us', [\App\Http\Controllers\PagesController::class, 'contactus'])->name('contact-us');
Route::get('/terms-and-conditions', [\App\Http\Controllers\PagesController::class, 'terms'])->name('terms');
Route::get('/refundpolicy', [\App\Http\Controllers\PagesController::class, 'refundpolicy'])->name('refundpolicy');
Route::get('/privacypolicy', [\App\Http\Controllers\PagesController::class, 'privacypolicy'])->name('privacypolicy');