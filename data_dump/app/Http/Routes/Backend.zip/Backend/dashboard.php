<?php
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\SettingsController;
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/reports', [DashboardController::class, 'reports'])->name('reports');



Route::get("decline-receipt/{id}",[DashboardController::class, 'declineReceipt']);
Route::get("approve-receipt/{id}",[DashboardController::class, 'approveReceipt']);
Route::get("send-invoice/{id}",[DashboardController::class, 'sendInvoice']); // copy

Route::post("edit-bank-account/{id}",[DashboardController::class, 'updateBankAccount']);
Route::get("edit-bank-account/{id}",[DashboardController::class, 'editBankAccount']);
Route::get("delete-bank-account/{id}",[DashboardController::class, 'deleteBankAccount']);
Route::post("add-bank-account",[DashboardController::class, 'insertBankAccount']);
Route::get("add-bank-account",[DashboardController::class, 'addBankAccount']);
Route::get("manage-bank-accounts",[DashboardController::class, 'manageBankAccounts']);
Route::post("authorizeNet-gateway-settings",[DashboardController::class, 'updateAuthorizeNetGatewaySettings']);
Route::get("authorizeNet-gateway-settings",[DashboardController::class, 'authorizeNetGatewaySettings']);

Route::post("paytabs-gateway-settings",[DashboardController::class, 'updatePaytabsGatewaySettings']);
Route::get("paytabs-gateway-settings",[DashboardController::class, 'paytabsGatewaySettings']);

Route::get("coinremitter-gateway-settings",[DashboardController::class, 'coinremitterGatewaySettings']);
Route::post("add-coinremitter-wallet",[DashboardController::class, 'storeCoinremitterWallet']);
Route::get("delete-coinremitter-wallet/{id}",[DashboardController::class, 'deleteCoinremitterWallet']);
Route::get("edit-coinremitter-wallet/{id}",[DashboardController::class, 'editCoinremitterWallet']);
Route::post("edit-coinremitter-wallet/{id}",[DashboardController::class, 'updateCoinremitterWallet']);
Route::get('/receipts', [DashboardController::class, 'receipts'])->name('receipts');
Route::get('/users', [DashboardController::class, 'users'])->name('users');
Route::get('/send_report', [DashboardController::class, 'send_report'])->name('send_report');
Route::post('/send_report', [DashboardController::class, 'send_report_email'])->name('send_report');
Route::get('/settings', [SettingsController::class, 'settings'])->name('settings');
Route::post('/settings', [SettingsController::class, 'updateSettings'])->name('settings');
Route::get('/checkvin', [SettingsController::class, 'checkvin'])->name('checkvin');
Route::post('/checkvin', [SettingsController::class, 'checkvinPost'])->name('checkvin');

