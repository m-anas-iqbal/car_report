<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CoinremitterWallet extends Model
{
	
	protected $table = "coinremitter_wallets";
	
}
